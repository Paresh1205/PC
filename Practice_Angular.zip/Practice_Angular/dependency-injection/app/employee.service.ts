import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class EmployeeService {

  constructor() { }

  getEmployees(){
    return [
      {"id":1,"name":"Paresh","age":25},
    {"id":2,"name":"Naresh","age":26},
    {"id":3,"name":"Taresh","age":27},
    {"id":4,"name":"Suresh","age":28}
    ];

  }


}
