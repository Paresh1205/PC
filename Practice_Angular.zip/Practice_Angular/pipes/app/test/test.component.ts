import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-test',
  templateUrl: './test.component.html',
  styleUrls: ['./test.component.css']
})
export class TestComponent implements OnInit {

  constructor() { }

  public name="Paresh Korani"
  public message="this is title demo for project";
  public person={
    "firstName":"Paresh",
    "lastName":"Korani"
  }
  public date=new Date();
  ngOnInit() {
  }

}
