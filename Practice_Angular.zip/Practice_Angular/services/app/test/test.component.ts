import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-test',
  templateUrl: './test.component.html',
  styleUrls: ['./test.component.css']
})
export class TestComponent implements OnInit {

  public employees = [
    {"id":1,"name":"Andrew","age":30},
    {"id":2,"name":"Jughead","age":28},
    {"id":3,"name":"Betty","age":25},
    {"id":4,"name":"Jason","age":27}
  ]
  constructor() { }

  ngOnInit() {
  }

}
