import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dept-list',
  templateUrl: './dept-list.component.html',
  styleUrls: ['./dept-list.component.css']
})
export class DeptListComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
