import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-style-binding',
  templateUrl: './style-binding.component.html',
  styleUrls: ['./style-binding.component.css']
})
export class StyleBindingComponent implements OnInit {

  public Name = "CodeEvolution";
  public hasError=true;
  public isSpl=true;
  public highlightcolor ="orange";
  public titlestyles={
    color:"blue",
    fontStyle:"italic"
  }

  constructor() { }

  ngOnInit() {
  }

}
