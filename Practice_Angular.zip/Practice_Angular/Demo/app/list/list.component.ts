import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-list',
  templateUrl: './list.component.html',
  styleUrls: ['./list.component.css']
})
export class ListComponent implements OnInit {

  public names="Paresh Korani";
  public successClass="text-success";
  public hasError=true;
  public isSpl=true;
  public messageclasses={
    "text-success":!this.hasError,
    "text-danger":this.hasError,
    "text-special":this.isSpl
  }



  constructor() { }

  ngOnInit() {
  }

  greeetUser(){
    return "Hello " + this.names;
  }
}
