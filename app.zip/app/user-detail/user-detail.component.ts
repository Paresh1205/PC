import { Component, OnInit } from '@angular/core';
import { UserService } from '../shared/user.service';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import { IUser } from '../shared/iuser';

@Component({
  selector: 'app-user-detail',
  templateUrl: './user-detail.component.html',
  styleUrls: ['./user-detail.component.css']
})
export class UserDetailComponent implements OnInit {

  public Users: Observable<IUser[]>;
  

  constructor(public userservice: UserService, protected router: Router) { }

  ngOnInit() {
    this.Users = JSON.parse(sessionStorage.getItem('user'));
  }

  backtolist() {
    this.router.navigateByUrl('/user-list');
  }

  submit(userform) {
    this.router.navigateByUrl('/confirm');
  }

}
